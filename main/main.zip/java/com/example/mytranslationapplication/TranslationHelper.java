package com.example.mytranslationapplication;


import android.util.Log;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.util.ArrayList;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

public class TranslationHelper {
    private static TranslationHelper translateHelper;
    private static final String TAG = "TranslateHelper";
    private Translator banglaEnglishTranslator;
    private DownloadConditions conditions;
    private List<TranslationObserver> observers = new ArrayList<>();
    public TranslationHelper(TranslationObserver observer){
        initializeTranslator(observer);
    }
    public static TranslationHelper getInstance(TranslationObserver observer){
        if(translateHelper == null)
            translateHelper = new TranslationHelper(observer);
        return translateHelper;
    }
    public static TranslationHelper getInstance(){
        return translateHelper;
    }

    private void initializeTranslator(TranslationObserver observer){
        addObserver(observer);
        TranslatorOptions options =
                new TranslatorOptions.Builder()
                        .setSourceLanguage(TranslateLanguage.BENGALI)
                        .setTargetLanguage(TranslateLanguage.ENGLISH)
                        .build();
        banglaEnglishTranslator =
                Translation.getClient(options);
        conditions = new DownloadConditions.Builder()
                .requireWifi()
                .build();
        observer.disableView(observer);
        banglaEnglishTranslator.downloadModelIfNeeded(conditions)
                .addOnSuccessListener(new OnSuccessListener() {
                    @Override
                    public void onSuccess(Object o) {
                        for(TranslationObserver observer: observers)
                            observer.enableView(o);
                        Log.d(TAG, "downloadModelIfNeeded");
                    }
                });
    }
    public void translateText(String text){
        banglaEnglishTranslator.translate(text)
                .addOnSuccessListener(new OnSuccessListener() {
                    @Override
                    public void onSuccess(Object o) {
                        Log.d(TAG, "translation: " + o.toString());
                        notifyObservers(o);
                    }
                });
    }
    public void closeTranslator(){
        banglaEnglishTranslator.close();
    }
    private void addObserver(TranslationObserver observer){
        if(!observers.contains(observer))
            observers.add(observer);
    }

    private void removeObserver(TranslationObserver observer){
        if(observers.contains(observer))
            observers.remove(observer);
    }
    private void notifyObservers(Object o){
        for(TranslationObserver observer: observers)
            observer.update(o);
    }
}
