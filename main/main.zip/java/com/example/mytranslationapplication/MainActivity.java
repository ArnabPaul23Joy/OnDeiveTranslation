package com.example.mytranslationapplication;

import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;


import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements TranslationObserver {

    private AppBarConfiguration appBarConfiguration;
    private TextView textView;
    private EditText editText;
    private Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textview_first);
        editText = findViewById(R.id.translate_text);
        button = findViewById(R.id.button_first);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                TranslationHelper.getInstance().translateText(editText.getText().toString());
            }
        });
        TranslationHelper.getInstance(this);
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        TranslationHelper.getInstance().closeTranslator();
    }
    @Override
    public void update(Object o) {
        textView.setText(o.toString());
    }
    @Override
    public void enableView(Object o) {
        editText.setEnabled(true);
        button.setEnabled(true);
    }
    @Override
    public void disableView(Object o) {
        editText.setEnabled(false);
        button.setEnabled(false);
    }
}